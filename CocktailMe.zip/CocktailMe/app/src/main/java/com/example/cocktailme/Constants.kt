package com.example.cocktailme

const val BASE_URL = "www.thecocktaildb.com/api/json/v1/"
const val API_KEY = ""