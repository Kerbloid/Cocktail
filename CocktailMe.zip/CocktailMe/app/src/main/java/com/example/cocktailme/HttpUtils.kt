package com.example.cocktailme

import okhttp3.OkHttpClient
import retrofit2.Retrofit

object HttpUtils {
    val service: Service = Retrofit.Builder()
        .baseUrl("http://www.foo.com/")
        .client(
            OkHttpClient.Builder()
            .build())
        .build()
        .create(Service::class.java)
}