package com.example.cocktailme


import com.google.gson.annotations.SerializedName

data class Ingredient(
    @SerializedName("ingredients")
    val ingredients: List<IngredientX>
)