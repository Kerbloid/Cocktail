package com.example.cocktailme

import retrofit2.http.GET

interface Service {
    @GET

}